//
//  ViewController.swift
//  Bank
//
//  Created by Горохов Никита Исип20 on 26.02.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }

    @IBAction func showPopUp(_ sender: UIButton){
        
    }
}

