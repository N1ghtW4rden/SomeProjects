//
//  ViewController.swift
//  WeatherApp
//
//  Created by Горохов Никита Исип20 on 12.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var cityTempLabel: UILabel!
    @IBOutlet weak var weekDayLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var inputCityName: UITextField!
    
    @IBAction func showCityNameAction(_ sender: Any){
        let urlString = "https://api.weatherapi.com/v1/current.json?key=51d9c6e249ce440098523719221203&q=\(inputCityName.text!)"

                let url = URL(string: urlString)
                let session = URLSession(configuration: .default)
                let task = session.dataTask(with: url!) { data, response, error in
                
                    if let data = data{
                    
                        self.parseJSON(withData: data)
                       /* let dataString = String(data: data, encoding: .utf8)
                        print(dataString!)*/
                        
                    }
                }
                task.resume()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
            }
    
        func parseJSON(withData data: Data) {
            let decoder = JSONDecoder()
            do {
                let apiItem = try decoder.decode(WeatherApp.self, from: data)
                cityNameLabel.text = apiItem.location.name
                cityTempLabel.text = String(apiItem.current.tempC)
                countryLabel.text = apiItem.location.country
                weekDayLabel.text = apiItem.current.lastUpdated
                conditionLabel.text = String(apiItem.current.condition.text)
               
            } catch let error as NSError {
                print(error.localizedDescription)
        }
    
    }
}
