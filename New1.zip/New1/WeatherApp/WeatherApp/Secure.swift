//
//  Secure.swift
//  WeatherApp
//
//  Created by Горохов Никита Исип20 on 12.03.2022.
//

import Foundation


let apiKey = "51d9c6e249ce440098523719221203"
