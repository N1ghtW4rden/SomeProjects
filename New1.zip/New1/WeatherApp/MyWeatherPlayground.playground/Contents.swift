import UIKit

func weatherData() {

    let urlString = "https://api.weatherapi.com/v1/current.json?key=a2d2600a0957489984812418221203&q=Moscow&aqi=no"

    let url = URL(string: urlString)
    let session = URLSession(configuration: .default)
    let task = session.dataTask(with: url!) { data, response, error in
        
        if let data = data{
            
            let dataString = String(data: data, encoding: .utf8)
            print(dataString!)
        }
    }
    task.resume()
}

weatherData()
